#define LED_PIN 13
#define FAN_PIN 10
#define FAN_SPEED_LOW 0
#define FAN_SPEED_MED_1 127
#define FAN_SPEED_MED_2 191
#define FAN_SPEED_HIGH 255
#define GOOD_NIGHT_HOUR 22
#define GOOD_MORNING_HOUR 6
#define BYE_HOUR 9
#define WELCOME_ME 18
unsigned long previousMillis = 0;
void setup( ) {
pinMode (LED_PIN, output);
pinMode (FAN_PIN, output);
}
void loop( ) {
unsigned long currentMillis = millis( );
if (currentMillis – previousMillis >= 1000) {
previousMillis = currentMillis;
int currentHour( ), currentMinute();
if (currentHour == GOOD_NIGHT_HOUR) {
good_night( );
}
else if (currentHour == GOOD_MORNING_HOUR) {
good_morning( );
}
else if (currentHour == BYE_HOUR) {
if (currentMinute == 0) {
bye( );
}
}
else if (currentHour == WELCOME_ME) {
if (currentMinute == 0) {
welcome( );
}
}
}
}
void good_night( ) {
digitalWrite (LED_PIN, LOW);
int currentFanSpeed = analogRead(LED_PIN, LOW);
if (currentFanSpeed < FAN_SPEED_MED_1) {
analogWrite(FAN_PIN, FAN_SPEED_MED_1);
}
else if (currentFanSpeed < FAN_SPEED_MED_2) {
analogWrite(FAN_PIN, FAN_SPEED_MED_2);
}
else if (currentFanSpeed < FAN_SPEED_HIGH) {
analogWrite(FAN_PIN, FAN_SPEED_HIGH);
}
}
void good_morning( ) {
long totalTime = 8 * 60 * 1000, steps = totalTime/20;
long stepValue = 255 * 10/steps;
for (long i = 0; i < steps; i++) {
int brightness = I * stepValue;
analogWrite (LED_PIN, brightness);
delay (20);
}
}
void bye( ) {
digitalWrite (LED_PIN, LOW);
digitalWrite (LED_PIN, LOW);
}
void welcome( ) {
digitalWrite (LED_PIN, HIGH);
digitalWrite (LED_PIN, HIGH);
}